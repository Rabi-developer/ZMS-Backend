﻿namespace IMS.Domain.Base;

//public static class ClaimTypes 
//{
//    public const string AuthorizationClaim = "Authorization";
//    public const string UserId = "UserId";
//    public const string AccessLevelClaim = "AccessLevel";
//    public const string AccessLevelDetailsClaim = "AccessLevelDetails";
//    public const string ResourceClaimPrefix = "Resource_"; //-> Its Value will be Actions.
//    // But, how to manage specific resources or Specific AccessLevels...?

//    public static string ResourceClaim(string resource)
//    {
//        return ResourceClaimPrefix + resource;
//    }
//}
