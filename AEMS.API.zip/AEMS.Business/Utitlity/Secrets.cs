﻿namespace IMS.Business.Utitlity;

public static class Secrets
{
    public static string AuthenticationSchemeSecretKey = "AEMS2024-194ef06e-d363-4248-af19-3e4afb52a926";
    public static string AuthenticationSchemeIssuer = "aems-auth-issuer";
    public static string AuthenticationSchemeAudience = "aems-auth-audience";
}
