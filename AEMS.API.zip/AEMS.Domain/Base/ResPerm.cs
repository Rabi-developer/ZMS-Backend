﻿namespace IMS.Domain.Base;

public class ResPerm
{
    public string ResourceName { get; set; }
}
