﻿namespace IMS.Business.DTOs.Responses;

public class KeyValue
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}
